Documentation in this directory is intended to be converted to other formats using [pandoc](http://pandoc.org/).

An online HTML version can be found at [https://daurnimator.github.io/lua-http/](https://daurnimator.github.io/lua-http/)

The *Makefile* in this directory should be used to compile the documentation.
